# LongShot Auto Scroll – Android Accessibility companion

## What this builds

A separate Android application named **LongShot Auto Scroll** to use alongside the already installed LongShot V2 APK. It does not replace or modify that APK. Adds a floating **HOLD ↓** button that scrolls accessible content while it is touched and held, and an **AUTO ▶ / STOP ■** toggle. The app itself does NOT capture images; the original LongShot app performs capture and stitching.

## Requirements

- Android 8+; designed for Android 14.
- Explicit user permission: Settings > Accessibility > LongShot Auto Scroll > On.
- Some Android 13+ devices restrict enabling Accessibility for sideloaded applications. In Settings > Apps > LongShot Auto Scroll > ⋮ > Allow restricted settings, enable this only if you trust the app.
- The app to be scrolled must expose a scrollable accessibility node. This works on common scrollable views, but not all custom widgets, images, games, secure applications or PDFs. In AUTO mode, the app can try a swipe gesture when no scrollable node exists.

## On-phone usage

1. Install the generated companion APK while **keeping your original LongShot V2 APK installed**.
2. Open the companion, choose **OPEN ACCESSIBILITY SETTINGS**, enable its service.
3. In the original LongShot, authorize screen capture and overlay; select the region and enable **Start auto**.
4. Go to the target app and press and hold the floating **HOLD ↓** button. Release to stop. If the hold is interrupted, use **AUTO ▶** to toggle scrolling and **STOP ■** when finished.
5. Adjust the original LongShot's lower corner, then use **Finish / Save PNG** there.

## Build

Open this project in Android Studio, or upload the folder contents to the root of a GitHub repository, then run **Actions > Build LongShot Auto Scroll Companion APK > Run workflow**. Download the produced `LongShot-Auto-Scroll-Companion-APK` artifact from the workflow run, unzip it, and install `app-debug.apk`.

## Security and limitations

This project uses the Android Accessibility Service API solely to scroll an app that the user chose. It does not read/save screen text or require network permission. Android will display the normal accessibility disclosure and may require extra settings steps for sideloaded applications.

The original APK has an automatic *frame-capture* feature but does not initiate scrolling in another application. This standalone service supplies scrolling, not capture itself. Repeated page-level accessibility scroll actions may jump too far for the original app's stitching algorithm; some apps may not scroll at all. It has not been installed/tested on an Android handset in this environment. Do not treat it as a verified drop-in replacement APK.

## Build using just 2 uploads on Android phone

Upload `LongShot_AutoScroll_Companion_Source.zip` at the repository root. Create `.github/workflows/build-longshot.yml` by pasting the separately supplied `build-longshot.yml` file contents, or upload that file at exactly that folder path. Run the workflow and download the artifact.
