package com.rushi.longshot.autoscroll;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density * v + .5f); }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22),dp(32),dp(22),dp(20));
        layout.setBackgroundColor(Color.rgb(248,250,252));
        TextView title = new TextView(this);
        title.setText("LongShot Auto Scroll");
        title.setTextSize(24f); title.setTextColor(Color.rgb(17,24,39));
        title.setTypeface(null, Typeface.BOLD);
        layout.addView(title);
        TextView instructions = new TextView(this);
        instructions.setText("COMPANION FOR YOUR EXISTING LONGSHOT APP\n\n" +
            "1. Enable LongShot Auto Scroll in Accessibility settings.\n"+
            "2. Open the original LongShot app and start its screen capture.\n"+
            "3. Open the app or page you want to capture.\n"+
            "4. Tap Start auto in the original LongShot controls, if available.\n"+
            "5. Touch and HOLD the new floating HOLD ↓ button to scroll; release to stop.\n"+
            "6. Adjust LongShot's lower crop corner, then Finish and Save PNG.\n\n" +
            "There is also an AUTO / STOP button if your phone cancels long touches.\n\n" +
            "Note: Scrolling depends on the other app exposing a scrollable accessibility view. Some games, secure apps and custom content may not scroll.");
        instructions.setTextSize(16f);
        instructions.setTextColor(Color.rgb(51,65,85));
        instructions.setLineSpacing(dp(4),1f);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-1,-2);
        textParams.topMargin=dp(18);layout.addView(instructions,textParams);
        Button enable = new Button(this);
        enable.setText("OPEN ACCESSIBILITY SETTINGS");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        LinearLayout.LayoutParams btn = new LinearLayout.LayoutParams(-1,dp(56));btn.topMargin=dp(22);
        layout.addView(enable,btn);
        TextView footer = new TextView(this);
        footer.setText("Privacy: No network permission; screen text is not saved. Enable this service only when capturing screenshots.");
        footer.setTextSize(13f);footer.setTextColor(Color.DKGRAY);footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams foot = new LinearLayout.LayoutParams(-1,-2);foot.topMargin=dp(20);
        layout.addView(footer,foot);
        setContentView(layout);
    }
}
