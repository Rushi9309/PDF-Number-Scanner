package com.rushi.longshot.autoscroll;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.DisplayMetrics;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

/**
 * Visible user-operated scroll control: while held, repeatedly asks the target app
 * to scroll forward through Android's Accessibility API. No root/ADB is needed.
 * It never reads or stores the target's text: only scrollability and child nodes.
 */
public class ScrollAccessibilityService extends AccessibilityService {
    private WindowManager wm;
    private LinearLayout overlay;
    private TextView mode;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean scrolling = false;
    private boolean continuous = false;
    private boolean overlayShown = false;
    private static final long INTERVAL_MS = 1250L;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!scrolling) return;
            try {
                boolean didScroll=scrollCurrentApp();
                // Some apps expose no scrollable accessibility node. In AUTO
                // mode a normal swipe gesture is a fallback; it may cancel a held touch.
                if (!didScroll && continuous) swipeDownPage();
            } catch (Throwable ignored) { }
            if (scrolling) handler.postDelayed(this,INTERVAL_MS);
        }
    };
    private int dp(float value) {return (int)(getResources().getDisplayMetrics().density * value + 0.5f);}

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        try { showControls(); } catch (Throwable ignored) { }
    }
    private TextView button(String name, int color) {
        TextView t = new TextView(this);
        t.setText(name);t.setTextSize(13);t.setTypeface(null,Typeface.BOLD);
        t.setTextColor(Color.WHITE);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(9),dp(10),dp(9),dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color); bg.setCornerRadius(dp(11));
        t.setBackground(bg);
        return t;
    }
    private void showControls() {
        if (overlayShown) return;
        wm = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.HORIZONTAL);
        overlay.setGravity(Gravity.CENTER);
        overlay.setPadding(dp(3),dp(3),dp(3),dp(3));
        TextView hold=button("HOLD ↓",Color.rgb(18,122,107));
        mode=button("AUTO ▶",Color.rgb(23,47,78));
        LinearLayout.LayoutParams holdParams=new LinearLayout.LayoutParams(dp(100),dp(53));
        LinearLayout.LayoutParams modeParams=new LinearLayout.LayoutParams(dp(98),dp(53));
        modeParams.leftMargin=dp(6);
        overlay.addView(hold,holdParams); overlay.addView(mode,modeParams);
        hold.setOnTouchListener((v,e)->{
            int action=e.getActionMasked();
            if (action==MotionEvent.ACTION_DOWN) {
                if (!continuous) startScroll(false);
                v.setPressed(true);
                return true;
            }
            if (action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) {
                if (!continuous) stopScroll();
                v.setPressed(false);
                return true;
            }
            return true;
        });
        mode.setOnClickListener(v->{
            if (continuous) stopScroll();
            else startScroll(true);
        });
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        params.x=dp(8);params.y=dp(135); // keep below-corner selector free and control visible
        wm.addView(overlay,params);
        overlayShown=true;
    }
    private void startScroll(boolean keepGoing) {
        handler.removeCallbacks(tick);
        continuous=keepGoing; scrolling=true;
        if (mode != null) mode.setText(continuous ? "STOP ■" : "AUTO ▶");
        handler.post(tick);
    }
    private void stopScroll() {
        handler.removeCallbacks(tick);
        scrolling=false;continuous=false;
        if (mode!=null) mode.setText("AUTO ▶");
    }

    /** Deepest scrollable node gets priority over the containing window. */
    private boolean scrollNode(AccessibilityNodeInfo node, int depth, int[] visited) {
        if (node==null || depth > 22 || visited[0]++ > 600) return false;
        int children;
        try { children=node.getChildCount(); } catch (Throwable ex) {children=0;}
        for (int i=children-1;i>=0;i--) {
            AccessibilityNodeInfo child=null;
            try {child=node.getChild(i);} catch(Throwable ignored){}
            if (child==null) continue;
            boolean didScroll=false;
            try {didScroll=scrollNode(child,depth+1,visited);} catch(Throwable ignored){}
            try {child.recycle();} catch(Throwable ignored){}
            if (didScroll) return true;
        }
        try {
            if (node.isScrollable())
                return node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
        } catch (Throwable ignored) {}
        return false;
    }
    private boolean scrollCurrentApp() {
        // Try target app window first. An accessibility overlay should never be scrolled.
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows!=null) {
                for (AccessibilityWindowInfo window:windows) {
                    if (window.getType()!=AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                    AccessibilityNodeInfo root=window.getRoot();
                    if(root==null)continue;
                    boolean done=false;
                    try {done=scrollNode(root,0,new int[1]);}
                    finally {try{root.recycle();}catch(Throwable ignored){}}
                    if(done)return true;
                }
            }
        } catch(Throwable ignored) {}
        AccessibilityNodeInfo root=null;
        try {
            root=getRootInActiveWindow();
            if(root!=null) return scrollNode(root,0,new int[1]);
        } finally {if(root!=null)try{root.recycle();}catch(Throwable ignored){}}
        return false;
    }
    private void swipeDownPage() {
        DisplayMetrics m=getResources().getDisplayMetrics();
        float x=m.widthPixels*0.50f;
        float startY=m.heightPixels*0.78f;
        float endY=m.heightPixels*0.39f;
        Path p=new Path();
        p.moveTo(x,startY);p.lineTo(x,endY);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(p,0,480);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture,null,null);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Nothing collected. */ }
    @Override public void onInterrupt() { stopScroll(); }
    @Override public void onDestroy() {
        stopScroll();
        if (overlayShown && wm!=null && overlay!=null) {
            try {wm.removeViewImmediate(overlay);}catch(Throwable ignored){}
        }
        overlay=null;overlayShown=false;wm=null;
        super.onDestroy();
    }
}
