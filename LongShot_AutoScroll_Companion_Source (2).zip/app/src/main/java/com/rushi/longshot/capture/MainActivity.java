package com.rushi.longshot.capture;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(22),dp(28),dp(22),dp(22));
        panel.setBackgroundColor(Color.rgb(245,248,251));
        TextView name = new TextView(this);
        name.setText("LongShot — Capture + Auto Scroll");
        name.setTextSize(23f);
        name.setTypeface(null,Typeface.BOLD);
        name.setTextColor(Color.rgb(24,35,51));
        panel.addView(name);
        TextView info = new TextView(this);
        info.setText("ALL-IN-ONE SCREENSHOT MODE\n\n" +
          "1. Enable the app's Accessibility service below.\n" +
          "2. Open the screen, website or document you want to save.\n" +
          "3. Tap floating START to capture the first frame.\n" +
          "4. Hold HOLD ↓ to capture while scrolling, or tap AUTO for hands-free scrolling.\n" +
          "5. Tap STOP at your chosen endpoint. Drag the END LINE to the exact place where the screenshot should finish.\n" +
          "6. Tap CAPTURE & SAVE. Look for the PNG in Gallery → Pictures → LongShot.\n\n" +
          "The app uses Android's Accessibility screenshot API. It won't capture protected/DRM screens, and some apps block automated swipes. " +
          "It tries to remove overlapping content between frames; accuracy varies on animated or rapidly changing pages.\n\n" +
          "The screenshot and its temporary frames stay on your phone. No network access is used.");
        info.setTextSize(15f); info.setTextColor(Color.rgb(58,72,91));
        info.setLineSpacing(dp(4),1f);
        LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(-1,-2); t.topMargin=dp(18);
        panel.addView(info,t);
        Button enable=new Button(this);
        enable.setText("OPEN ACCESSIBILITY SETTINGS");
        enable.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(-1,dp(58)); b.topMargin=dp(22);
        panel.addView(enable,b);
        TextView privacy=new TextView(this);
        privacy.setText("Enable this powerful permission only if you trust the app. Turn it off when you finish capturing.");
        privacy.setGravity(Gravity.CENTER);privacy.setTextSize(12f);privacy.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(20);panel.addView(privacy,p);
        ScrollView scroll=new ScrollView(this);scroll.addView(panel);
        setContentView(scroll);
    }
}
