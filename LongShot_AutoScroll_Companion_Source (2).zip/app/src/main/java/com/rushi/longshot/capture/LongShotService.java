package com.rushi.longshot.capture;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * An explicitly user-controlled capture service. No network permission, no background capture.
 * Android 11+ AccessibilityService.takeScreenshot handles screen capture without MediaProjection.
 */
public class LongShotService extends AccessibilityService {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ArrayList<File> frames=new ArrayList<>();
    private WindowManager windowManager;
    private WindowManager.LayoutParams markerParams;
    private LinearLayout controls;
    private LinearLayout endMarker;
    private TextView autoButton,status;
    private boolean running=false,automatic=false,holding=false,shotBusy=false,gestureBusy=false;
    private boolean saveAfterShot=false,saving=false,showMarker=false;
    private int runId=0,stillCount=0;
    private static final int MAX_FRAMES=60;

    private int dp(float px){return (int)(getResources().getDisplayMetrics().density*px+0.5f);}
    private void message(String text){
        if(status!=null)status.setText(text);
    }
    private void toast(String text){Toast.makeText(getApplicationContext(),text,Toast.LENGTH_LONG).show();}
    private TextView button(String text,int background){
        TextView view=new TextView(this);
        view.setText(text);view.setTextColor(Color.WHITE);view.setTextSize(12);
        view.setTypeface(null,Typeface.BOLD);view.setGravity(Gravity.CENTER);
        view.setPadding(dp(8),dp(9),dp(8),dp(9));
        GradientDrawable shape=new GradientDrawable();shape.setColor(background);
        shape.setCornerRadius(dp(10));view.setBackground(shape);
        return view;
    }
    private LinearLayout.LayoutParams layout(int weight,int marginDp){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,weight);
        lp.leftMargin=dp(marginDp);
        return lp;
    }
    @Override protected void onServiceConnected(){
        super.onServiceConnected();
        try {makeOverlay();}catch(Throwable ex){toast("Cannot show capture buttons: "+ex.getMessage());}
    }
    private void makeOverlay(){
        if(controls!=null)return;
        windowManager=(WindowManager)getSystemService(Context.WINDOW_SERVICE);
        if(windowManager==null)return;
        controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(6),dp(5),dp(6),dp(5));
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(29,38,52));bg.setCornerRadius(dp(13));
        controls.setBackground(bg);
        LinearLayout line=new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);line.setGravity(Gravity.CENTER_VERTICAL);
        TextView start=button("START",Color.rgb(26,115,91));
        TextView hold=button("HOLD ↓",Color.rgb(37,104,140));
        autoButton=button("AUTO ▶",Color.rgb(49,63,113));
        TextView stop=button("STOP",Color.rgb(154,58,53));
        line.addView(start,layout(1,0));
        line.addView(hold,layout(1,3));
        line.addView(autoButton,layout(1,3));
        line.addView(stop,layout(1,3));
        controls.addView(line,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout lower=new LinearLayout(this);
        lower.setOrientation(LinearLayout.HORIZONTAL);
        lower.setGravity(Gravity.CENTER_VERTICAL);
        TextView capture=button("CAPTURE & SAVE PNG",Color.rgb(15,145,125));
        status=new TextView(this);status.setText("Ready — press START");
        status.setTextSize(11);status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cap=new LinearLayout.LayoutParams(0,dp(40),2.1f);
        LinearLayout.LayoutParams stat=new LinearLayout.LayoutParams(0,dp(40),1.2f);
        stat.leftMargin=dp(6);
        lower.addView(capture,cap);lower.addView(status,stat);
        LinearLayout.LayoutParams lowerParams=new LinearLayout.LayoutParams(-1,-2);
        lowerParams.topMargin=dp(5);controls.addView(lower,lowerParams);
        start.setOnClickListener(v->startNew());
        hold.setOnTouchListener((v,event)->{
            int action=event.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN){
                if(!saving){holding=true;automatic=false;updateAuto();
                    if(!running)startNew();else drive();}
                return true;
            }
            if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
                holding=false;return true;
            }
            return true;
        });
        autoButton.setOnClickListener(v->{
            if(saving)return;
            if(automatic){automatic=false;updateAuto();message("Auto paused · "+frames.size()+" frames");}
            else{automatic=true;holding=false;updateAuto();
                if(!running)startNew();else drive();}
        });
        stop.setOnClickListener(v->stopAtCurrentPosition());
        capture.setOnClickListener(v->captureAndSave());
        WindowManager.LayoutParams overlayParams=new WindowManager.LayoutParams(
            -1,-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        overlayParams.gravity=Gravity.BOTTOM|Gravity.LEFT;
        overlayParams.y=dp(45);overlayParams.x=0;
        windowManager.addView(controls,overlayParams);
        createEndMarker();
    }
    private void createEndMarker(){
        endMarker=new LinearLayout(this);endMarker.setGravity(Gravity.CENTER_VERTICAL);
        endMarker.setOrientation(LinearLayout.HORIZONTAL);
        TextView handle=button("▼ END LINE · DRAG",Color.rgb(196,83,40));
        endMarker.addView(handle,new LinearLayout.LayoutParams(dp(165),dp(42)));
        View guide=new View(this);guide.setBackgroundColor(Color.rgb(255,122,34));
        endMarker.addView(guide,new LinearLayout.LayoutParams(0,dp(3),1));
        markerParams=new WindowManager.LayoutParams(
            -1,dp(46),WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        markerParams.gravity=Gravity.TOP|Gravity.LEFT;
        DisplayMetrics metrics=getResources().getDisplayMetrics();
        markerParams.y=(int)(metrics.heightPixels*.82f);markerParams.x=0;
        final float[] pointer=new float[2];
        handle.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    pointer[0]=e.getRawY();pointer[1]=markerParams.y;return true;
                case MotionEvent.ACTION_MOVE:
                    markerParams.y=Math.max(dp(90),Math.min(metrics.heightPixels-dp(70),
                        (int)(pointer[1]+e.getRawY()-pointer[0])));
                    windowManager.updateViewLayout(endMarker,markerParams);return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:return true;
            }
            return true;
        });
        windowManager.addView(endMarker,markerParams);
        endMarker.setVisibility(View.GONE);
    }
    private void updateAuto(){
        if(autoButton!=null)autoButton.setText(automatic?"PAUSE ■":"AUTO ▶");
    }
    private void removeFrames(){
        for(File f:frames)try{f.delete();}catch(Throwable ignored){}
        frames.clear();
    }
    private void startNew(){
        if(saving||shotBusy||gestureBusy){toast("Finish the current capture first");return;}
        runId++;stillCount=0;running=true;saveAfterShot=false;
        showMarker=false;endMarker.setVisibility(View.GONE);
        removeFrames();
        message("Capturing first frame …");
        takeFrame(()->drive());
    }
    private void drive(){
        if(!running||(!automatic&&!holding)||shotBusy||gestureBusy||saving)return;
        if(frames.size()>=MAX_FRAMES){
            automatic=false;holding=false;updateAuto();
            toast("60 frames captured. Tap STOP, then CAPTURE & SAVE.");
            return;
        }
        gestureBusy=true;
        DisplayMetrics m=getResources().getDisplayMetrics();
        float x=m.widthPixels*.50f,startY=m.heightPixels*.78f,endY=m.heightPixels*.35f;
        Path path=new Path();path.moveTo(x,startY);path.lineTo(x,endY);
        GestureDescription gesture=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path,0,650)).build();
        boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){
                gestureBusy=false;
                if(running) main.postDelayed(()->takeFrame(()->drive()),650);
                else if(saveAfterShot)tryCaptureAndSave();
            }
            @Override public void onCancelled(GestureDescription g){
                gestureBusy=false;automatic=false;holding=false;updateAuto();
                message("Scroll interrupted · tap AUTO to resume");
                if(saveAfterShot)tryCaptureAndSave();
            }
        },main);
        if(!accepted){gestureBusy=false;automatic=false;holding=false;updateAuto();message("This app blocked the scroll gesture");}
    }
    private void stopAtCurrentPosition(){
        automatic=false;holding=false;running=false;updateAuto();
        showMarker=true;endMarker.setVisibility(View.VISIBLE);
        message("Drag END LINE, then CAPTURE");
    }
    private void captureAndSave(){
        if(saving)return;
        automatic=false;holding=false;running=false;updateAuto();
        saveAfterShot=true;
        showMarker=true;endMarker.setVisibility(View.VISIBLE);
        tryCaptureAndSave();
    }
    private void tryCaptureAndSave(){
        if(!saveAfterShot||shotBusy||gestureBusy||saving)return;
        saveAfterShot=false;
        message("Taking final frame …");
        takeFrame(()->saveFrames());
    }
    private void takeFrame(Runnable after){
        if(shotBusy||saving)return;
        shotBusy=true;
        // Hide our controls for the single screenshot. The floating UI never appears in the PNG.
        if(controls!=null)controls.setVisibility(View.INVISIBLE);
        if(endMarker!=null)endMarker.setVisibility(View.INVISIBLE);
        final int sequence=runId;
        main.postDelayed(()->{
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                    @Override public void onSuccess(ScreenshotResult capture){
                        HardwareBuffer hardware=capture.getHardwareBuffer();
                        Bitmap bmp=null;
                        try {
                            Bitmap wrapped=Bitmap.wrapHardwareBuffer(hardware,capture.getColorSpace());
                            if(wrapped==null)throw new IOException("Android returned an empty screenshot");
                            bmp=wrapped.copy(Bitmap.Config.ARGB_8888,false);
                            wrapped.recycle();
                            if(bmp==null)throw new IOException("Cannot copy screenshot pixels");
                        }catch(Throwable err){
                            if(bmp!=null)bmp.recycle();
                            restoreOverlay();shotBusy=false;automatic=false;holding=false;updateAuto();
                            message("Screen capture failed: "+err.getMessage());return;
                        }finally{try{hardware.close();}catch(Throwable ignored){}}
                        final Bitmap savedBitmap=bmp;
                        io.execute(()->{
                            File output=null;String error=null;
                            try {
                                output=File.createTempFile("longshot_frame_",".png",getCacheDir());
                                try(FileOutputStream stream=new FileOutputStream(output)){
                                    if(!savedBitmap.compress(Bitmap.CompressFormat.PNG,100,stream))
                                        throw new IOException("PNG encoding failed");
                                }
                            }catch(Throwable problem){
                                error=problem.getMessage();if(output!=null)output.delete();output=null;
                            }finally {savedBitmap.recycle();}
                            final File file=output;final String failure=error;
                            main.post(()->{
                                restoreOverlay();shotBusy=false;
                                if(sequence!=runId){if(file!=null)file.delete();return;}
                                if(file==null){
                                    automatic=false;holding=false;updateAuto();
                                    message("Capture error: "+failure);return;
                                }
                                frames.add(file);
                                message(frames.size()+" frames captured");
                                if(frames.size()>1){
                                    File prior=frames.get(frames.size()-2);
                                    io.execute(()->{
                                        boolean same=LongShotStitcher.essentiallySame(prior,file);
                                        main.post(()->{
                                            if(sequence!=runId)return;
                                            if(same)stillCount++;else stillCount=0;
                                            if(stillCount>=2&&automatic){
                                                automatic=false;holding=false;running=false;
                                                updateAuto();showMarker=true;
                                                endMarker.setVisibility(View.VISIBLE);
                                                message("Reached end · drag END LINE / CAPTURE");
                                            }else if(after!=null)after.run();
                                            if(saveAfterShot)tryCaptureAndSave();
                                        });
                                    });
                                }else {
                                    if(after!=null)after.run();
                                    if(saveAfterShot)tryCaptureAndSave();
                                }
                            });
                        });
                    }
                    @Override public void onFailure(int errorCode){
                        restoreOverlay();shotBusy=false;
                        automatic=false;holding=false;updateAuto();
                        message("Android denied screenshot (code "+errorCode+"). Try again.");
                        toast("Screenshot blocked. Protected apps cannot be captured.");
                    }
                });
            }catch(Throwable error){
                restoreOverlay();shotBusy=false;automatic=false;holding=false;updateAuto();
                message("Capture not available: "+error.getMessage());
            }
        },200);
    }
    private void restoreOverlay(){
        if(controls!=null)controls.setVisibility(View.VISIBLE);
        if(endMarker!=null)endMarker.setVisibility(showMarker?View.VISIBLE:View.GONE);
    }
    private int markerEndPixel(){
        if(endMarker==null)return Integer.MAX_VALUE;
        int[] location=new int[2];endMarker.getLocationOnScreen(location);
        return location[1]+dp(22);
    }
    private void saveFrames(){
        if(saving||shotBusy||frames.isEmpty())return;
        saving=true;
        message("Stitching and saving …");
        final List<File> snapshot=new ArrayList<>(frames);
        final int line=markerEndPixel();
        io.execute(()->{
            Uri result=null;String error=null;
            try {result=LongShotStitcher.save(getApplicationContext(),snapshot,line);}
            catch(Throwable e){error=e.getMessage();}
            final Uri uri=result;final String fail=error;
            main.post(()->{
                saving=false;
                if(uri!=null){
                    message("SAVED ✓ Pictures/LongShot");
                    toast("Saved long screenshot to Pictures/LongShot");
                }else{
                    message("Save failed: "+fail);
                    toast("Save failed: "+fail);
                }
            });
        });
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){/* No content collected or transmitted. */}
    @Override public void onInterrupt(){
        automatic=false;holding=false;running=false;updateAuto();
    }
    @Override public void onDestroy(){
        automatic=false;holding=false;running=false;
        main.removeCallbacksAndMessages(null);
        if(windowManager!=null){
            try{if(controls!=null)windowManager.removeViewImmediate(controls);}catch(Throwable ignored){}
            try{if(endMarker!=null)windowManager.removeViewImmediate(endMarker);}catch(Throwable ignored){}
        }
        controls=null;endMarker=null;
        io.shutdown();
        super.onDestroy();
    }
}
