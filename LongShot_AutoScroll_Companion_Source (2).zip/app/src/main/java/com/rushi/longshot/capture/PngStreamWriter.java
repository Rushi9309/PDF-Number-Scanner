package com.rushi.longshot.capture;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

/** Constant-memory, lossless RGBA PNG encoding (rows are supplied on demand). */
public final class PngStreamWriter {
    private PngStreamWriter() { }
    public interface Rows { void getRow(int y, int[] argb) throws IOException; }
    private static final byte[] SIGNATURE = {(byte)137,80,78,71,13,10,26,10};
    private static void writeInt(OutputStream out,int n)throws IOException {
        out.write((n >>> 24)&255);out.write((n >>> 16)&255);
        out.write((n >>> 8)&255);out.write(n&255);
    }
    private static void chunk(OutputStream out, String type, byte[] data, int off, int len)throws IOException {
        writeInt(out,len);
        byte[] kind=type.getBytes("US-ASCII");
        out.write(kind);
        CRC32 crc=new CRC32();crc.update(kind);
        if (len>0){out.write(data,off,len);crc.update(data,off,len);}
        writeInt(out,(int)crc.getValue());
    }
    private static final class IdatOutput extends OutputStream {
        private final OutputStream stream;
        private final ByteArrayOutputStream buffer=new ByteArrayOutputStream(65536);
        IdatOutput(OutputStream stream){this.stream=stream;}
        @Override public void write(int b)throws IOException {
            buffer.write(b);
            if(buffer.size()>=65536)flushChunk();
        }
        @Override public void write(byte[] b,int off,int len)throws IOException {
            while(len>0){
                int part=Math.min(65536-buffer.size(),len);
                buffer.write(b,off,part);off+=part;len-=part;
                if(buffer.size()>=65536)flushChunk();
            }
        }
        void finish()throws IOException{flushChunk();}
        private void flushChunk()throws IOException {
            if(buffer.size()==0)return;
            byte[] payload=buffer.toByteArray();
            chunk(stream,"IDAT",payload,0,payload.length);
            buffer.reset();
        }
    }
    public static void write(OutputStream out,int width,int height,Rows rows)throws IOException {
        if(width<=0||height<=0||width>20000||height>1200000)
            throw new IOException("Image dimensions exceed safety limit");
        out.write(SIGNATURE);
        ByteArrayOutputStream ihdr=new ByteArrayOutputStream();
        writeInt(ihdr,width);writeInt(ihdr,height);
        ihdr.write(8);ihdr.write(6);ihdr.write(0);ihdr.write(0);ihdr.write(0); // RGBA, noninterlaced
        byte[] header=ihdr.toByteArray();
        chunk(out,"IHDR",header,0,header.length);
        IdatOutput idat=new IdatOutput(out);
        DeflaterOutputStream compressor=new DeflaterOutputStream(idat,new Deflater(6,false),65536,true);
        int[] pixels=new int[width];byte[] line=new byte[width*4+1];
        line[0]=0; // filter None
        for(int y=0;y<height;y++){
            rows.getRow(y,pixels);
            int p=1;
            for(int value:pixels){
                line[p++]=(byte)(value>>>16);
                line[p++]=(byte)(value>>>8);
                line[p++]=(byte)value;
                line[p++]=(byte)(value>>>24);
            }
            compressor.write(line);
        }
        compressor.finish(); compressor.flush(); idat.finish();
        chunk(out,"IEND",new byte[0],0,0);
    }
}
