package com.rushi.longshot.capture;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Matches adjacent screenshot frames and writes a tall lossless PNG one row at a time.
 * No network access or 3rd-party dependency; memory stays near one source screenshot.
 */
public final class LongShotStitcher {
    private LongShotStitcher() { }
    private static final class Segment {
        final File file; final int start, end;
        Segment(File file,int start,int end){this.file=file;this.start=start;this.end=end;}
        int height(){return end-start;}
    }
    private static Bitmap small(File file) throws IOException {
        BitmapFactory.Options options=new BitmapFactory.Options();
        options.inSampleSize=4;options.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Bitmap bitmap=BitmapFactory.decodeFile(file.getAbsolutePath(),options);
        if(bitmap==null)throw new IOException("Could not decode recorded frame");
        return bitmap;
    }
    private static double difference(Bitmap a,Bitmap b,int delta){
        int w=a.getWidth(),h=a.getHeight();
        if(w!=b.getWidth()||h!=b.getHeight())return Double.POSITIVE_INFINITY;
        int top=(int)(h*0.12f),bottom=(int)(h*0.88f)-delta;
        if(bottom-top<35)return Double.POSITIVE_INFINITY;
        long error=0;int n=0;
        for(int y=top;y<bottom;y+=13){
            for(int x=w/8;x<w*7/8;x+=Math.max(12,w/12)){
                int p=a.getPixel(x,y+delta),q=b.getPixel(x,y);
                error+=Math.abs(((p>>16)&255)-((q>>16)&255));
                error+=Math.abs(((p>>8)&255)-((q>>8)&255));
                error+=Math.abs((p&255)-(q&255));
                n+=3;
            }
        }
        return n==0?Double.POSITIVE_INFINITY:(double)error/n;
    }
    private static int estimateShift(Bitmap a,Bitmap b,int fullHeight) {
        int h=a.getHeight();
        if(a.getWidth()!=b.getWidth()||h!=b.getHeight()) return -1;
        double still=difference(a,b,0);
        if(still<3.8)return 0;
        int best=0;double bestScore=still;
        int max=(int)(h*0.64f);
        for(int d=2;d<=max;d+=2){
            double score=difference(a,b,d);
            // Slightly prefer the smaller shift when scores tie.
            if(score+0.3<bestScore){best=d;bestScore=score;}
        }
        // Poor match: use the gesture's approximate travel rather than skip the page.
        if(best==0||bestScore>30)return Math.round(fullHeight*0.43f);
        return Math.max(0,Math.min((int)(fullHeight*0.64f),Math.round(best*(fullHeight/(float)h))));
    }
    static boolean essentiallySame(File previous,File latest){
        Bitmap a=null,b=null;
        try {
            a=small(previous);b=small(latest);
            return difference(a,b,0)<4.5;
        }catch(Throwable ignored){return false;}
        finally{if(a!=null)a.recycle();if(b!=null)b.recycle();}
    }
    private static int frameShift(File first,File second,int fullHeight) throws IOException {
        Bitmap a=null,b=null;
        try {
            a=small(first);b=small(second);
            return estimateShift(a,b,fullHeight);
        } finally {if(a!=null)a.recycle();if(b!=null)b.recycle();}
    }
    public static Uri save(Context context,List<File> frames,int endPixel) throws IOException {
        if(frames==null||frames.isEmpty()) throw new IOException("No screenshots recorded. Tap START first.");
        BitmapFactory.Options dims=new BitmapFactory.Options();dims.inJustDecodeBounds=true;
        BitmapFactory.decodeFile(frames.get(0).getAbsolutePath(),dims);
        int width=dims.outWidth,height=dims.outHeight;
        if(width<1||height<1)throw new IOException("Cannot read screenshot dimensions");
        // Ignore the Android gesture/navigation area in the bottom 4% of each frame.
        // This prevents repeating the phone's navigation bar at every join.
        int contentEnd=height-Math.max(12,(int)(height*0.035f));
        int chosenEnd=Math.max(30,Math.min(contentEnd,endPixel));
        List<Segment> segments=new ArrayList<>();
        segments.add(new Segment(frames.get(0),0,contentEnd));
        long total=contentEnd;
        for(int i=1;i<frames.size();i++){
            BitmapFactory.Options measure=new BitmapFactory.Options();measure.inJustDecodeBounds=true;
            BitmapFactory.decodeFile(frames.get(i).getAbsolutePath(),measure);
            if(measure.outWidth!=width||measure.outHeight!=height)
                throw new IOException("The screen rotated during capture. Keep portrait orientation fixed.");
            int shift=frameShift(frames.get(i-1),frames.get(i),height);
            if(shift<0)throw new IOException("Inconsistent frame sizes");
            if(shift==0)continue;
            shift=Math.min(shift,contentEnd);
            segments.add(new Segment(frames.get(i),contentEnd-shift,contentEnd));
            total+=shift;
        }
        long target=total-(contentEnd-chosenEnd);
        if(target<1||target>1200000)throw new IOException("Result is outside supported PNG height range");
        final int outHeight=(int)target;
        String fileName="LongShot_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".png";
        ContentValues values=new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME,fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/LongShot");
        values.put(MediaStore.Images.Media.IS_PENDING,1);
        ContentResolver resolver=context.getContentResolver();
        Uri uri=resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(uri==null)throw new IOException("Cannot create an image in Pictures/LongShot");
        try {
            try(OutputStream stream=resolver.openOutputStream(uri)){
                if(stream==null)throw new IOException("Cannot write the image file");
                final List<Segment> spans=new ArrayList<>();
                long remaining=outHeight;
                for(Segment segment:segments){
                    if(remaining<=0)break;
                    int size=(int)Math.min(segment.height(),remaining);
                    if(size>0)spans.add(new Segment(segment.file,segment.start,segment.start+size));
                    remaining-=size;
                }
                if(remaining!=0)throw new IOException("Frame alignment did not cover target height");
                final Bitmap[] current={null};
                final int[] at={0},local={0};
                try {
                    PngStreamWriter.write(stream,width,outHeight,(y,argb)->{
                        while(at[0]<spans.size()&&local[0]>=spans.get(at[0]).height()){
                            if(current[0]!=null){current[0].recycle();current[0]=null;}
                            at[0]++;local[0]=0;
                        }
                        if(at[0]>=spans.size())throw new IOException("Missing frame data");
                        Segment s=spans.get(at[0]);
                        if(current[0]==null){
                            current[0]=BitmapFactory.decodeFile(s.file.getAbsolutePath());
                            if(current[0]==null)throw new IOException("Cannot decode "+s.file.getName());
                        }
                        current[0].getPixels(argb,0,width,0,s.start+local[0],width,1);
                        local[0]++;
                    });
                }finally {if(current[0]!=null)current[0].recycle();}
            }
            ContentValues ready=new ContentValues();
            ready.put(MediaStore.Images.Media.IS_PENDING,0);
            resolver.update(uri,ready,null,null);
            return uri;
        }catch(Throwable problem){
            resolver.delete(uri,null,null);
            if(problem instanceof IOException)throw (IOException)problem;
            throw new IOException(problem);
        }
    }
}
