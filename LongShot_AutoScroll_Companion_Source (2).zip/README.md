# LongShot Capture + Auto Scroll (Android 11+)

## Purpose

**This is a new all-in-one Android source project, replacing the scroll-only companion.**
It includes the user-operated floating START, HOLD, AUTO, STOP and **CAPTURE & SAVE PNG** buttons and a draggable **END LINE**. It does not communicate over the Internet.

### How it works

1. Install the APK built from this source.
2. Open LongShot Capture + Scroll and tap **OPEN ACCESSIBILITY SETTINGS**.
3. Under downloaded apps, enable **LongShot Capture + Scroll**.
   On Android 13/14, sideloaded apps may require Apps -> LongShot Capture + Scroll -> three dots -> **Allow restricted settings**, then return to Accessibility. Enable only after reviewing/trusting the source.
4. Open any permitted screen, web page or scrollable document. Floating controls are near the bottom of the screen.
5. Tap **START** to record the first visible screen.
6. Use **HOLD ↓** to scroll while pressed, or **AUTO ▶** to scroll repeatedly with frame capture. Tap AUTO again to pause.
7. Tap **STOP** at the desired position. Drag the orange **END LINE** up/down to the exact screenshot endpoint.
8. Tap **CAPTURE & SAVE PNG**. The screenshot is saved to **Pictures/LongShot** and appears in Gallery.

**Note:** Screenshot controls disappear briefly during each frame capture so they are not included in the saved image.

### Technical approach

- AccessibilityService with `android:canTakeScreenshot="true"` and `android:canPerformGestures="true"`.
- `AccessibilityService.takeScreenshot` (Android 11+ API 30) takes frames only after user-initiated START/CAPTURE. It does not need MediaProjection or screen recording service.
- `dispatchGesture` makes a continuous vertical swipe using a stable overlap between screenshots. HOLD and AUTO are controlled by the user.
- Frame PNGs temporarily stored in the app's private cache. Neighboring frames compared using sampled-pixel vertical shift alignment to remove overlap.
- Image saved to MediaStore in `Pictures/LongShot`; a custom row-streaming lossless PNG encoder avoids allocating one huge bitmap in memory.
- User can finish at an arbitrary visible vertical position by moving the orange END LINE before CAPTURE & SAVE.
- No Internet permission, no data uploaded, no automatic unattended screenshot capture.

### Known restrictions

- It cannot capture protected/secure screens, DRM video, or content that Android blocks from screenshots.
- Some apps do not accept simulated swipe gestures, and fixed headers, animations, videos, or complex layouts can defeat pixel overlap matching.
- Screenshot stitching is **not guaranteed** to be seamless, especially on dynamic pages or rapidly updating websites. Maximum 60 frames per session.
- Avoid rotating the phone mid-capture. Android 11+ required.
- Debug builds are signed by the GitHub runner; their signing key may change between workflow runs. Uninstall previous debug versions of **this same package** before installing a new build, and save images first. This build has a **different package name** from the previous scroll-only app, so they can coexist.
- The source has been syntax-parsed with Java 17; the streaming PNG writer has been round-trip tested with Pillow. **The full Android app has not been compiled or handset-tested in this environment.**

### Build with the existing GitHub setup (only one replacement file)

If your repository already has `.github/workflows/build-longshot.yml` with `android-actions/setup-android@v4`, and that workflow extracts `LongShot_AutoScroll_Companion_Source.zip` into the `project` folder:

1. Download the *new* `LongShot_AutoScroll_Companion_Source.zip` supplied with this project.
2. In your GitHub repository's **Code** tab, select **Add file -> Upload files**, and upload this ZIP to the repository root, **replacing the old ZIP with the same name**.
3. Commit the change.
4. Go to **Actions -> Build LongShot Auto Scroll Companion APK -> Run workflow**.
5. When the workflow succeeds, open its artifacts and download the APK ZIP, extract it, and install `app-debug.apk`.
6. Look for a **new app icon, 'LongShot Capture + Scroll'**. Open it and enable its own Accessibility service. The old **LongShot Auto Scroll** app can then be disabled or uninstalled.

### Build in a new GitHub repository

Unzip this archive locally and upload all its contents to the root of the new repository (including the `.github/workflows/build-apk.yml` path), then run **Actions -> Build LongShot Capture And Auto Scroll APK**. The debug APK appears in workflow artifacts.
